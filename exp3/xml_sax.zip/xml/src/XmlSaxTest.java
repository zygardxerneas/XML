import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class XmlSaxTest {

             /**
       * @param args
       */
             public static void main(String[] args) {
                 // TODO Auto-generated method stub
                 //query1_output.xml
                 ArrayList<Map<String, String>> list=(ArrayList<Map<String, String>>)SaxService.ReadXML("query1_output.xml","catalog");
                 for(int i=0;i<list.size();i++)
                 {
                     HashMap<String, String> temp=(HashMap<String, String>) list.get(i);
                     Iterator<String> iterator=temp.keySet().iterator();
                     while(iterator.hasNext())
                     {
                         String key=iterator.next().toString();
                         String value=temp.get(key);
                         System.out.print(key+" "+value);
                         System.out.println();
                     }
                     System.out.println();
                 }

                 //System.out.println(list.toString());
             }
}