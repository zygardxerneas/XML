import org.w3c.dom.*;
import org.xml.sax.SAXException;

import javax.swing.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class SaxUI {

    private JPanel panel1;
    private JTextArea textArea1;
    private JButton button1;
    private JButton button2;

    public static void main(String[] args) {
        JFrame frame = new JFrame("DOMUI");
        frame.setContentPane(new SaxUI().panel1);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setResizable(false);
        frame.pack();



        frame.setVisible(true);
    }

    public SaxUI(){

        textArea1.setEditable(false);

        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textArea1.setText("");
                ArrayList<Map<String, String>> list=(ArrayList<Map<String, String>>)SaxService.ReadXML("query1_output.xml","catalog");
                print(list);
            }
        });

        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                textArea1.setText("");
                ArrayList<Map<String, String>> list=(ArrayList<Map<String, String>>)SaxService.ReadXML("query2_output.xml","catalog");
                print(list);
            }
        });
    }

    public void print(ArrayList<Map<String,String>> list)
    {
        for(int i=0;i<list.size();i++)
        {
            HashMap<String, String> temp=(HashMap<String, String>) list.get(i);
            Iterator<String> iterator=temp.keySet().iterator();
            while(iterator.hasNext())
            {
                String key=iterator.next().toString();
                String value=temp.get(key);
                String temps=key+" "+value+"\n";
                textArea1.append(temps);
            }
            textArea1.append("\n");
        }
    }

}
